"""Scene timing + caption chunks + SRT/JSON export."""
from __future__ import annotations

import json
from pathlib import Path


def word_times(scenes: list[dict], events: list[dict], duration: float) -> tuple[list[tuple[float, float, str]], str]:
    """Return [(start, end, word)] for the whole script and a note on how it was timed."""
    words = [w for s in scenes for w in s["narration"].split()]
    if events and len(events) == len(words):
        return [(e["start"], e["end"], w) for e, w in zip(events, words)], "exact word timing from the voice engine"
    # estimated: weight by characters over the whole duration
    weights = [max(1, len(w)) + 1 for w in words]
    total = float(sum(weights))
    out, cur = [], 0.0
    for w, wt in zip(words, weights):
        d = duration * wt / total
        out.append((cur, cur + d, w))
        cur += d
    return out, "estimated word timing"


def scene_spans(scenes: list[dict], times: list[tuple[float, float, str]], duration: float) -> list[tuple[float, float]]:
    spans, idx = [], 0
    starts = []
    for s in scenes:
        starts.append(times[idx][0] if idx < len(times) else duration)
        idx += len(s["narration"].split())
    starts[0] = 0.0
    for i, st in enumerate(starts):
        en = starts[i + 1] if i + 1 < len(starts) else duration
        spans.append((st, max(en, st + 0.5)))
    return spans


def chunks(times: list[tuple[float, float, str]], per: int = 4, end_at: float | None = None) -> list[dict]:
    out = []
    for i in range(0, len(times), per):
        grp = times[i:i + per]
        nxt = times[i + per][0] if i + per < len(times) else None
        end = nxt if nxt is not None else (end_at if end_at is not None else grp[-1][1] + 0.3)
        out.append({"start": grp[0][0], "end": max(end, grp[0][0] + 0.25), "text": " ".join(w for _, _, w in grp)})
    return out


def _ts(sec: float) -> str:
    ms = max(0, int(round(sec * 1000)))
    h, ms = divmod(ms, 3600000)
    m, ms = divmod(ms, 60000)
    s, ms = divmod(ms, 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def write_srt(caps: list[dict], path: Path) -> str:
    rows = [f"{i}\n{_ts(c['start'])} --> {_ts(c['end'])}\n{c['text']}\n" for i, c in enumerate(caps, 1)]
    path.write_text("\n".join(rows), encoding="utf-8")
    return str(path)


def write_timestamps(caps: list[dict], duration: float, path: Path) -> str:
    path.write_text(json.dumps({"duration_seconds": round(duration, 3), "segments": [
        {"index": i, "start": round(c["start"], 3), "end": round(c["end"], 3), "text": c["text"]}
        for i, c in enumerate(caps, 1)]}, ensure_ascii=False, indent=2), encoding="utf-8")
    return str(path)
