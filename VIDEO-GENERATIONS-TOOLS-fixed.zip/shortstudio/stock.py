"""Free stock footage (Pexels / Pixabay). Keys are optional."""
from __future__ import annotations

import re
from pathlib import Path
from urllib.parse import urlparse

import requests

MAX_BYTES = 120 * 1024 * 1024
OK_HOSTS = ("pexels.com", "pixabay.com")


def search(provider: str, query: str, api_key: str, portrait: bool, per_page: int = 6) -> list[dict]:
    if not api_key:
        raise ValueError(f"Enter the {provider.title()} API key (free) or turn stock footage off.")
    if not query.strip():
        raise ValueError("Empty stock search phrase.")
    try:
        if provider == "pexels":
            r = requests.get("https://api.pexels.com/v1/videos/search", headers={"Authorization": api_key},
                             params={"query": query, "per_page": per_page,
                                     "orientation": "portrait" if portrait else "landscape"}, timeout=(10, 40))
            r.raise_for_status()
            return _pexels(r.json())
        if provider == "pixabay":
            r = requests.get("https://pixabay.com/api/videos/", params={"key": api_key, "q": query,
                             "per_page": max(3, per_page), "safesearch": "true"}, timeout=(10, 40))
            r.raise_for_status()
            return _pixabay(r.json())
    except requests.RequestException as exc:
        code = getattr(getattr(exc, "response", None), "status_code", "")
        raise RuntimeError(f"{provider.title()} search failed {code}: {str(exc)[:150]}") from exc
    raise ValueError("Choose pexels or pixabay.")


def _pexels(payload: dict) -> list[dict]:
    rows = []
    for v in payload.get("videos", []):
        files = [f for f in v.get("video_files", []) if f.get("link") and f.get("file_type") == "video/mp4"]
        if not files:
            continue
        # prefer ~720-1080 wide: good quality, small download
        files.sort(key=lambda f: abs(int(f.get("height") or 0) - 1280))
        rows.append({"id": f"pexels-{v['id']}", "source": "Pexels", "creator": (v.get("user") or {}).get("name", ""),
                     "credit_url": v.get("url", ""), "download_url": files[0]["link"], "duration": v.get("duration", 0)})
    return rows


def _pixabay(payload: dict) -> list[dict]:
    rows = []
    for h in payload.get("hits", []):
        vids = h.get("videos") or {}
        pick = vids.get("medium") or vids.get("large") or vids.get("small")
        if pick and pick.get("url"):
            rows.append({"id": f"pixabay-{h['id']}", "source": "Pixabay", "creator": h.get("user", ""),
                         "credit_url": h.get("pageURL", ""), "download_url": pick["url"], "duration": h.get("duration", 0)})
    return rows


def download(item: dict, folder: Path) -> str:
    url = str(item.get("download_url") or "")
    host = urlparse(url).hostname or ""
    if urlparse(url).scheme != "https" or not any(host == h or host.endswith("." + h) for h in OK_HOSTS):
        raise ValueError("Download URL is not from an approved stock host.")
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / (re.sub(r"[^A-Za-z0-9_-]+", "-", item["id"])[:60] + ".mp4")
    if path.exists() and path.stat().st_size > 2048:
        return str(path)
    total = 0
    with requests.get(url, stream=True, timeout=(10, 60)) as r:
        r.raise_for_status()
        with path.open("wb") as f:
            for chunk in r.iter_content(1 << 20):
                total += len(chunk)
                if total > MAX_BYTES:
                    path.unlink(missing_ok=True)
                    raise ValueError("Stock clip is too large (>120 MB).")
                f.write(chunk)
    if path.stat().st_size < 2048:
        path.unlink(missing_ok=True)
        raise RuntimeError("Stock provider returned an invalid file.")
    return str(path)
