"""Simple Colab dashboard (ipywidgets): Voice, Captions, Style, Model/API + Generate + Download."""
from __future__ import annotations

import html
import io
import os
import shutil
import traceback
from pathlib import Path

import ipywidgets as w
from IPython.display import Audio, HTML, Video, clear_output, display

from . import llm, render
from .config import (CAPTION_STYLES, EDGE_VOICES, GTTS_LANGS, LANGUAGES, LLM_PROVIDERS, MMS_MODELS, QUALITY, STYLES,
                     VOICE_ENGINES)
from .pipeline import Settings, build_storyboard, generate, preview_voice

CSS = """<style>
.ss-title{font:700 22px system-ui;margin:4px 0 2px}.ss-sub{color:#667;font:14px system-ui;margin-bottom:8px}
.ss-ok{color:#0a7d35;font:600 14px system-ui}.ss-err{color:#b3261e;font:600 14px system-ui;white-space:pre-wrap}
.ss-info{color:#245;font:14px system-ui}
</style>"""
SAMPLE = {"bn": ("আপনার ভিডিওর টাইটেল", "এখানে ক্যাপশন দেখা যাবে"), "hi": ("आपके वीडियो का शीर्षक", "यहाँ कैप्शन दिखेगा"),
          "ur": ("آپ کی ویڈیو کا عنوان", "یہاں کیپشن نظر آئے گا"), "ar": ("عنوان الفيديو", "هنا يظهر التعليق"),
          "en": ("Your video title", "Captions will appear here")}
SECRET_NAMES = {"openrouter": "OPENROUTER_API_KEY", "groq": "GROQ_API_KEY", "gemini": "GEMINI_API_KEY",
                "deepseek": "DEEPSEEK_API_KEY", "openai": "OPENAI_API_KEY", "pexels": "PEXELS_API_KEY",
                "pixabay": "PIXABAY_API_KEY"}


def _secret(name: str) -> str:
    try:
        from google.colab import userdata  # type: ignore
        return userdata.get(name) or ""
    except Exception:
        return os.environ.get(name, "")


def _in_colab() -> bool:
    try:
        import google.colab  # type: ignore  # noqa: F401
        return True
    except Exception:
        return False


class Studio:
    def __init__(self, work_dir: str | Path, export_dir: str | Path):
        self.work_dir, self.export_dir = Path(work_dir), Path(export_dir)
        self.work_dir.mkdir(parents=True, exist_ok=True)
        self.export_dir.mkdir(parents=True, exist_ok=True)
        L = w.Layout(width="100%")
        ds = {"description_width": "130px"}
        # ---- input
        self.language = w.Dropdown(options=[(v, k) for k, v in LANGUAGES.items()], value="bn", description="Language", style=ds, layout=L)
        self.script = w.Textarea(placeholder="Paste your script here (works with NO API key). Or leave empty and type a topic below.",
                                 layout=w.Layout(width="100%", height="170px"))
        self.topic = w.Text(placeholder="Topic (needs an LLM key in tab 4)", description="Topic", style=ds, layout=L)
        self.notes = w.Textarea(placeholder="Optional: one scene idea per line (used as stock-footage search words)",
                                layout=w.Layout(width="100%", height="60px"))
        self.duration = w.IntSlider(value=45, min=15, max=120, step=5, description="Length (topic)", style=ds, layout=L)
        # ---- 1 voice
        self.engine = w.Dropdown(options=[(v, k) for k, v in VOICE_ENGINES.items()], value="edge", description="Engine", style=ds, layout=L)
        self.voice = w.Dropdown(options=[(f"{v}  [{k}]", k) for k, v in EDGE_VOICES.items()], value="bn-BD-NabanitaNeural",
                                description="Voice", style=ds, layout=L)
        self.gtts_lang = w.Dropdown(options=[(v, k) for k, v in GTTS_LANGS.items()], value="bn", description="Voice language", style=ds, layout=L)
        self.mms_model = w.Dropdown(options=[(v, k) for k, v in MMS_MODELS.items()], value="facebook/mms-tts-ben", description="MMS model", style=ds, layout=L)
        self.rate = w.IntSlider(value=0, min=-40, max=40, description="Speed %", style=ds, layout=L)
        self.pitch = w.IntSlider(value=0, min=-30, max=30, description="Pitch Hz", style=ds, layout=L)
        self.btn_voice = w.Button(description="▶ Preview voice", button_style="info", icon="volume-up")
        self.voice_out = w.Output()
        # ---- 2 captions
        self.cap_style = w.Dropdown(options=[(v, k) for k, v in CAPTION_STYLES.items()], value="box", description="Caption style", style=ds, layout=L)
        self.cap_words = w.IntSlider(value=4, min=2, max=6, description="Words per line", style=ds, layout=L)
        self.brand = w.Text(placeholder="Channel name shown at top (optional)", description="Channel name", style=ds, layout=L)
        # ---- 3 style
        self.style = w.Dropdown(options=[(v["label"], k) for k, v in STYLES.items()], value="cinematic", description="Visual style", style=ds, layout=L)
        self.aspect = w.ToggleButtons(options=[("Shorts 9:16", "9:16"), ("Wide 16:9", "16:9")], value="9:16", description="Format", style=ds)
        self.quality = w.Dropdown(options=list(QUALITY.items()), value=720, description="Quality", style=ds, layout=L)
        self.preview_img = w.Image(format="png", layout=w.Layout(max_width="340px", max_height="420px", object_fit="contain"))
        # ---- 4 model / api
        self.provider = w.Dropdown(options=[(v["label"], k) for k, v in LLM_PROVIDERS.items()], value="openrouter", description="LLM provider", style=ds, layout=L)
        self.api_key = w.Password(placeholder="API key (kept only in this session)", description="API key", style=ds, layout=L)
        self.base_url = w.Text(placeholder="Only for 'Custom' provider, e.g. https://host/v1", description="Base URL", style=ds, layout=L)
        self.model = w.Combobox(placeholder="Pick or type a model id", options=[], description="Model", style=ds, layout=L, ensure_option=False)
        self.free_only = w.Checkbox(value=True, description="OpenRouter: show only free models", indent=False)
        self.btn_models = w.Button(description="Load models", icon="refresh")
        self.btn_test = w.Button(description="Test connection", icon="plug")
        self.api_out = w.Output()
        self.stock = w.Dropdown(options=[("None (generated backgrounds, no key)", "none"), ("Pexels footage (free key)", "pexels"),
                                         ("Pixabay footage (free key)", "pixabay")], value="none", description="Stock footage", style=ds, layout=L)
        self.stock_key = w.Password(placeholder="Pexels/Pixabay API key", description="Stock key", style=ds, layout=L)
        self.music = w.FileUpload(accept=".mp3,.wav,.m4a", multiple=False, description="Background music (optional)", layout=w.Layout(width="auto"))
        # ---- run
        self.btn_gen = w.Button(description="🎬  Generate video", button_style="success", layout=w.Layout(width="100%", height="52px"))
        self.status = w.HTML("")
        self.result_out = w.Output()
        self.dl_out = w.Output()
        self._wire()
        self._refresh_voice_rows()
        self._refresh_preview()
        self._fill_secrets()

    # ---- wiring
    def _wire(self):
        self.engine.observe(lambda _: self._refresh_voice_rows(), "value")
        self.language.observe(self._lang_changed, "value")
        for wd in (self.style, self.aspect, self.cap_style, self.brand):
            wd.observe(lambda _: self._refresh_preview(), "value")
        self.provider.observe(lambda _: self._fill_secrets(), "value")
        self.stock.observe(lambda _: self._fill_secrets(), "value")
        self.btn_voice.on_click(self._on_voice)
        self.btn_models.on_click(self._on_models)
        self.btn_test.on_click(self._on_test)
        self.btn_gen.on_click(self._on_generate)

    def _fill_secrets(self):
        for box, name in ((self.api_key, self.provider.value), (self.stock_key, self.stock.value)):
            if name in SECRET_NAMES and not box.value:
                box.value = _secret(SECRET_NAMES[name])
        info = LLM_PROVIDERS[self.provider.value]
        if info["default_model"] and not self.model.value:
            self.model.value = info["default_model"]

    def _lang_changed(self, _):
        defaults = {"bn": "bn-BD-NabanitaNeural", "hi": "hi-IN-SwaraNeural", "ur": "ur-PK-UzmaNeural",
                    "ar": "ar-SA-ZariyahNeural", "en": "en-IN-NeerjaNeural"}
        self.voice.value = defaults[self.language.value]
        self.gtts_lang.value = self.language.value
        self.mms_model.value = "facebook/mms-tts-hin" if self.language.value == "hi" else "facebook/mms-tts-ben"
        self._refresh_preview()

    def _refresh_voice_rows(self):
        e = self.engine.value
        self.voice.layout.display = "" if e == "edge" else "none"
        self.rate.layout.display = self.pitch.layout.display = "" if e == "edge" else "none"
        self.gtts_lang.layout.display = "" if e == "gtts" else "none"
        self.mms_model.layout.display = "" if e == "mms" else "none"

    def _refresh_preview(self):
        try:
            t, c = SAMPLE[self.language.value]
            img = render.preview_frame(self.style.value, self.aspect.value, t, c, self.cap_style.value, self.brand.value.strip())
            buf = io.BytesIO()
            img.save(buf, "PNG")
            self.preview_img.value = buf.getvalue()
        except Exception as exc:  # preview is cosmetic; show why instead of crashing the dashboard
            self.status.value = f'<span class="ss-err">Preview unavailable: {html.escape(str(exc))}</span>'

    # ---- settings
    def settings(self) -> Settings:
        music = None
        if self.music.value:
            item = self.music.value[0] if isinstance(self.music.value, (list, tuple)) else list(self.music.value.values())[0]
            if isinstance(item, dict):  # ipywidgets 7 (Colab) and 8 use different shapes
                name = item.get("name") or (item.get("metadata") or {}).get("name") or "music.mp3"
                content = item["content"]
            else:
                name, content = item.name, item.content
            p = self.work_dir / ("music" + Path(name).suffix)
            p.write_bytes(bytes(content))
            music = str(p)
        return Settings(
            script=self.script.value, topic=self.topic.value.strip(), scene_notes=self.notes.value, language=self.language.value,
            duration=self.duration.value, style=self.style.value, aspect=self.aspect.value, quality_height=self.quality.value,
            brand=self.brand.value.strip(), voice_engine=self.engine.value, voice=self.voice.value, voice_rate=self.rate.value,
            voice_pitch=self.pitch.value, gtts_lang=self.gtts_lang.value, mms_model=self.mms_model.value,
            caption_style=self.cap_style.value, words_per_caption=self.cap_words.value, llm_provider=self.provider.value,
            llm_key=self.api_key.value.strip(), llm_model=self.model.value.strip(), llm_base_url=self.base_url.value.strip(),
            stock_provider=self.stock.value, stock_key=self.stock_key.value.strip(), music_path=music)

    # ---- handlers
    def _on_voice(self, _):
        with self.voice_out:
            clear_output()
            sample = {"bn": "আসসালামু আলাইকুম, এটি আমার ভয়েসের একটি নমুনা।", "hi": "नमस्ते, यह मेरी आवाज़ का एक नमूना है।",
                      "ur": "السلام علیکم، یہ میری آواز کا نمونہ ہے۔", "ar": "السلام عليكم، هذه عينة من صوتي.",
                      "en": "Hello, this is a sample of my voice."}[self.language.value]
            text = (self.script.value.strip()[:300] or sample)
            print("Generating preview…")
            try:
                path = preview_voice(text, self.work_dir, self.settings())
                clear_output()
                display(Audio(filename=path, autoplay=False))
            except Exception as exc:
                clear_output()
                display(HTML(f'<div class="ss-err">{html.escape(str(exc))}</div>'))

    def _on_models(self, _):
        with self.api_out:
            clear_output()
            try:
                models = llm.list_models(self.provider.value, self.api_key.value.strip(), self.base_url.value.strip() or None,
                                         self.free_only.value)
                self.model.options = models
                if models and self.model.value not in models:
                    self.model.value = models[0]
                display(HTML(f'<div class="ss-ok">Loaded {len(models)} models.</div>'))
            except Exception as exc:
                display(HTML(f'<div class="ss-err">{html.escape(str(exc))}</div>'))

    def _on_test(self, _):
        with self.api_out:
            clear_output()
            try:
                ans = llm.test_connection(self.provider.value, self.api_key.value.strip(), self.model.value.strip(),
                                          self.base_url.value.strip() or None)
                display(HTML(f'<div class="ss-ok">Connection OK — model replied: {html.escape(ans)}</div>'))
            except Exception as exc:
                display(HTML(f'<div class="ss-err">{html.escape(str(exc))}</div>'))

    def _download(self, path: str):
        with self.dl_out:
            clear_output()
            if _in_colab():
                from google.colab import files  # type: ignore
                files.download(path)
            else:
                display(HTML(f"Saved at: {html.escape(path)}"))

    def _on_generate(self, _):
        self.btn_gen.disabled = True
        self.result_out.clear_output()
        self.dl_out.clear_output()

        def say(msg: str):
            self.status.value = f'<span class="ss-info">⏳ {html.escape(msg)}</span>'

        try:
            s = self.settings()
            if not s.script.strip() and not s.topic:
                raise ValueError("Paste a script (no key needed) or type a topic.")
            res = generate(s, self.work_dir, self.export_dir, say)
            self.status.value = (f'<span class="ss-ok">✅ Done in {res["seconds_taken"]}s · video length {res["duration"]}s · '
                                 f'{html.escape(res["caption_timing"])}</span>')
            with self.result_out:
                size_mb = Path(res["video"]).stat().st_size / 1e6
                if size_mb <= 25:
                    display(Video(res["video"], embed=True, width=300 if s.aspect == "9:16" else 560))
                else:
                    display(HTML(f"<i>Video is {size_mb:.0f} MB, so the in-page player is skipped. Use Download.</i>"))
                for msg in res["warnings"]:
                    display(HTML(f'<div class="ss-err">⚠ {html.escape(msg)}</div>'))
                display(HTML(f'<div class="ss-info">Saved in: {html.escape(str(self.export_dir))}</div>'))
                row = []
                for label, key in (("⬇ Video (MP4)", "video"), ("⬇ Captions (SRT)", "srt"), ("⬇ Timestamps (JSON)", "timestamps")):
                    b = w.Button(description=label, button_style="primary" if key == "video" else "")
                    b.on_click(lambda _b, p=res[key]: self._download(p))
                    row.append(b)
                display(w.HBox(row))
                display(self.dl_out)
        except Exception as exc:
            self.status.value = f'<span class="ss-err">❌ {html.escape(str(exc))}</span>'
            with self.result_out:
                if os.environ.get("SHORTSTUDIO_DEBUG"):
                    traceback.print_exc()
        finally:
            self.btn_gen.disabled = False

    # ---- layout
    def show(self):
        t1 = w.VBox([self.engine, self.voice, self.gtts_lang, self.mms_model, self.rate, self.pitch, self.btn_voice, self.voice_out])
        t2 = w.VBox([self.cap_style, self.cap_words, self.brand, w.HTML("<i>Preview is in tab 3.</i>")])
        t3 = w.HBox([w.VBox([self.style, self.aspect, self.quality], layout=w.Layout(width="60%")), self.preview_img])
        t4 = w.VBox([self.provider, self.api_key, self.base_url, self.model, self.free_only, w.HBox([self.btn_models, self.btn_test]),
                     self.api_out, w.HTML("<hr>"), self.stock, self.stock_key, self.music])
        tabs = w.Tab(children=[t1, t2, t3, t4])
        for i, name in enumerate(["1 · Voice", "2 · Captions", "3 · Style", "4 · Model / API"]):
            tabs.set_title(i, name)
        display(HTML(CSS + '<div class="ss-title">🎬 Short Studio</div><div class="ss-sub">Script → voice → captions → MP4. '
                     'Free &amp; open-source. Only a pasted script is needed — no API key.</div>'))
        display(w.VBox([self.language, self.script, self.topic, self.notes, self.duration, tabs, self.btn_gen, self.status, self.result_out],
                       layout=w.Layout(max_width="860px")))
