"""Minimal OpenAI-compatible chat client (requests only; no heavy SDK)."""
from __future__ import annotations

import json
import re
import time
import requests

from .config import LLM_PROVIDERS


class LLMError(RuntimeError):
    pass


def _endpoint(provider: str, base_url: str | None) -> str:
    info = LLM_PROVIDERS.get(provider)
    if info is None:
        raise LLMError(f"Unknown provider: {provider}")
    url = (base_url or info["base_url"] or "").strip().rstrip("/")
    if not url:
        raise LLMError("Enter the base URL for this provider.")
    if not url.startswith("https://") and not url.startswith("http://localhost"):
        raise LLMError("Base URL must start with https://")
    return url


def _headers(api_key: str) -> dict:
    return {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}


def list_models(provider: str, api_key: str, base_url: str | None = None, free_only: bool = False) -> list[str]:
    if not api_key:
        raise LLMError("Enter the API key first.")
    url = _endpoint(provider, base_url) + "/models"
    try:
        r = requests.get(url, headers=_headers(api_key), timeout=(10, 30))
        r.raise_for_status()
    except requests.RequestException as exc:
        raise LLMError(f"Could not load models: {_explain(exc)}") from exc
    rows = r.json().get("data") or r.json().get("models") or []
    out: list[str] = []
    for row in rows:
        mid = str(row.get("id") or row.get("name") or "").removeprefix("models/")
        if not mid:
            continue
        if free_only and provider == "openrouter":
            pr = row.get("pricing") or {}
            if not (mid.endswith(":free") or (str(pr.get("prompt")) in ("0", "0.0") and str(pr.get("completion")) in ("0", "0.0"))):
                continue
        out.append(mid)
    if provider == "openrouter" and "openrouter/free" not in out:
        out.insert(0, "openrouter/free")
    return sorted(set(out), key=lambda m: (m != "openrouter/free", m.lower()))


def chat(provider: str, api_key: str, model: str, messages: list[dict],
         base_url: str | None = None, temperature: float = 0.5, max_tokens: int = 3000,
         retries: int = 2) -> str:
    if not api_key:
        raise LLMError("Enter the API key in the Model / API tab.")
    if not model:
        raise LLMError("Choose a model in the Model / API tab (press 'Load models').")
    url = _endpoint(provider, base_url) + "/chat/completions"
    body = {"model": model, "messages": messages, "temperature": temperature, "max_tokens": max_tokens}
    last: Exception | None = None
    for attempt in range(retries + 1):
        try:
            r = requests.post(url, headers=_headers(api_key), json=body, timeout=(10, 120))
            if r.status_code in (429, 500, 502, 503, 504) and attempt < retries:
                time.sleep(2 * (attempt + 1))
                continue
            r.raise_for_status()
            data = r.json()
            text = (data["choices"][0]["message"].get("content") or "").strip()
            if not text:
                raise LLMError("The model returned an empty answer. Pick another model.")
            return text
        except requests.RequestException as exc:
            last = exc
            if attempt >= retries:
                break
            time.sleep(1.5)
        except (KeyError, IndexError, ValueError) as exc:
            raise LLMError(f"Unexpected response from the provider: {exc}") from exc
    raise LLMError(f"Model request failed: {_explain(last)}")


def test_connection(provider: str, api_key: str, model: str, base_url: str | None = None) -> str:
    return chat(provider, api_key, model, [{"role": "user", "content": "Reply with the single word: ok"}],
                base_url, temperature=0, max_tokens=16, retries=0)[:60]


def _explain(exc: Exception | None) -> str:
    if exc is None:
        return "unknown error"
    resp = getattr(exc, "response", None)
    if resp is not None:
        snippet = (resp.text or "")[:200].replace("\n", " ")
        hint = {401: " (wrong API key)", 403: " (key not allowed)", 404: " (model or URL not found)",
                429: " (rate limit: wait a minute or pick another model)"}.get(resp.status_code, "")
        return f"HTTP {resp.status_code}{hint}: {snippet}"
    return str(exc)[:200]


def parse_json_object(text: str) -> dict:
    cleaned = re.sub(r"^```(?:json)?\s*|\s*```$", "", text.strip(), flags=re.I)
    try:
        value = json.loads(cleaned)
    except json.JSONDecodeError:
        a, b = cleaned.find("{"), cleaned.rfind("}")
        if a < 0 or b <= a:
            raise LLMError("The model did not return JSON. Try another model or paste your own script.")
        try:
            value = json.loads(cleaned[a:b + 1])
        except json.JSONDecodeError as exc:
            raise LLMError(f"The model returned broken JSON: {exc}") from exc
    if not isinstance(value, dict):
        raise LLMError("The model response is not a JSON object.")
    return value
