"""End-to-end orchestration: script/topic -> scenes -> stock -> voice -> timing -> MP4."""
from __future__ import annotations

import json
import shutil
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from pathlib import Path

from . import captions, planner, render, stock, tts


@dataclass
class Settings:
    script: str = ""
    topic: str = ""
    scene_notes: str = ""
    language: str = "bn"
    duration: int = 45                 # only used for topic mode
    # style
    style: str = "cinematic"
    aspect: str = "9:16"
    quality_height: int = 720
    brand: str = ""
    # voice
    voice_engine: str = "edge"
    voice: str = "bn-BD-NabanitaNeural"
    voice_rate: int = 0
    voice_pitch: int = 0
    gtts_lang: str = "bn"
    mms_model: str = "facebook/mms-tts-ben"
    # captions
    caption_style: str = "box"
    words_per_caption: int = 4
    # model / api
    llm_provider: str = "openrouter"
    llm_key: str = ""
    llm_model: str = ""
    llm_base_url: str = ""
    stock_provider: str = "none"       # none | pexels | pixabay
    stock_key: str = ""
    music_path: str | None = None
    extra: dict = field(default_factory=dict)


def _hook(board: dict) -> str:
    hook = (board.get("hook") or "").strip()
    first = board["scenes"][0].get("on_screen_text", "").strip()
    return "" if hook == first else hook


def _say(progress, msg: str):
    if progress:
        progress(msg)


def preview_voice(text: str, out_dir: Path, s: Settings) -> str:
    out = Path(out_dir) / f"preview_{uuid.uuid4().hex[:6]}.wav"
    res = tts.synthesize(text[:400], s.voice_engine, out, voice=s.voice, rate=s.voice_rate, pitch=s.voice_pitch,
                         lang=s.gtts_lang, mms_model=s.mms_model)
    return res["path"]


def build_storyboard(s: Settings) -> dict:
    if s.script.strip():
        return planner.scenes_from_script(s.script, s.scene_notes, s.topic)
    return planner.storyboard_from_topic(s.topic, s.language, s.style, s.duration, s.llm_provider,
                                         s.llm_key, s.llm_model, s.llm_base_url or None)


def _attach_stock(board: dict, s: Settings, job: Path, progress) -> list[str]:
    warnings: list[str] = []
    portrait = s.aspect == "9:16"

    def work(scene):
        try:
            results = stock.search(s.stock_provider, scene["stock_query"], s.stock_key, portrait)
            if not results:
                return f"{scene['id']}: no stock clip found for '{scene['stock_query']}' (generated background used)"
            scene["stock_file"] = stock.download(results[0], job / "stock")
            scene["stock_credit"] = {k: results[0][k] for k in ("source", "creator", "credit_url")}
        except Exception as exc:
            return f"{scene['id']}: stock failed ({str(exc)[:120]}); generated background used"
        return None

    _say(progress, "Downloading stock footage…")
    with ThreadPoolExecutor(max_workers=4) as pool:
        for msg in pool.map(work, board["scenes"]):
            if msg:
                warnings.append(msg)
    return warnings


def generate(s: Settings, work_dir: str | Path, export_dir: str | Path, progress=None) -> dict:
    t0 = time.time()
    job = Path(work_dir) / uuid.uuid4().hex[:8]
    job.mkdir(parents=True, exist_ok=True)
    export = Path(export_dir)
    export.mkdir(parents=True, exist_ok=True)

    _say(progress, "1/5 Preparing scenes…")
    board = build_storyboard(s)
    board.update(language=s.language, style=s.style, aspect=s.aspect)
    warnings: list[str] = []
    if s.stock_provider != "none":
        warnings += _attach_stock(board, s, job, progress)

    _say(progress, "2/5 Generating voice…")
    text = " ".join(sc["narration"] for sc in board["scenes"])
    if len(text) > 8000:
        raise ValueError("Script is too long for one short video (max 8000 characters).")
    voice = tts.synthesize(text, s.voice_engine, job / "narration.wav", voice=s.voice, rate=s.voice_rate,
                           pitch=s.voice_pitch, lang=s.gtts_lang, mms_model=s.mms_model)
    duration = voice["duration"]

    _say(progress, "3/5 Timing captions…")
    times, note = captions.word_times(board["scenes"], voice["events"], duration)
    spans = captions.scene_spans(board["scenes"], times, duration)
    caps_by_scene, idx = [], 0
    for sc, (st, en) in zip(board["scenes"], spans):
        cnt = len(sc["narration"].split())
        caps_by_scene.append(captions.chunks(times[idx:idx + cnt], max(2, min(6, s.words_per_caption)), end_at=en))
        idx += cnt
    all_caps = [c for grp in caps_by_scene for c in grp]

    _say(progress, "4/5 Rendering video (FFmpeg)…")
    video = render.render_video(job, board["scenes"], spans, caps_by_scene, voice["path"], s.music_path, s.style,
                                s.aspect, s.quality_height, s.caption_style, _hook(board), s.brand,
                                duration, progress)

    _say(progress, "5/5 Saving files…")
    stamp = time.strftime("%Y%m%d-%H%M%S")
    base = export / f"short-{stamp}"
    out = {"video": str(base) + ".mp4"}
    shutil.copy2(video, out["video"])
    out["srt"] = captions.write_srt(all_caps, Path(str(base) + ".srt"))
    out["timestamps"] = captions.write_timestamps(all_caps, duration, Path(str(base) + ".timestamps.json"))
    credits = [sc["stock_credit"] for sc in board["scenes"] if sc.get("stock_credit")]
    Path(str(base) + ".storyboard.json").write_text(json.dumps(
        {**{k: v for k, v in board.items() if k != "scenes"}, "caption_timing": note, "stock_credits": credits,
         "scenes": [{k: v for k, v in sc.items() if k != "stock_file"} for sc in board["scenes"]]},
        ensure_ascii=False, indent=2), encoding="utf-8")
    out["storyboard"] = str(base) + ".storyboard.json"
    out.update(duration=round(duration, 2), seconds_taken=round(time.time() - t0, 1), caption_timing=note,
               warnings=warnings, title=board.get("title", ""))
    return out
