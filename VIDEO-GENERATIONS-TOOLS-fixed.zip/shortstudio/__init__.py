"""Short Studio: free, open-source short-video generator for Google Colab."""
__version__ = "3.0.0"
