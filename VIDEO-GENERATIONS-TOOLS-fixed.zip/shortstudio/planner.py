"""Script -> storyboard. Pasted scripts are split locally (no LLM needed)."""
from __future__ import annotations

import re

from . import llm
from .config import STYLES, LANGUAGES

SENT_SPLIT = re.compile(r"(?<=[.!?।॥؟])\s+|\n+")


def sentences(text: str) -> list[str]:
    return [s.strip() for s in SENT_SPLIT.split(text.strip()) if s.strip()]


def split_scenes(text: str, target_words: int = 22, max_scenes: int = 14) -> list[str]:
    groups: list[str] = []
    cur: list[str] = []
    count = 0
    for s in sentences(text):
        cur.append(s)
        count += len(s.split())
        if count >= target_words:
            groups.append(" ".join(cur))
            cur, count = [], 0
    if cur:
        if groups and count < 6:
            groups[-1] += " " + " ".join(cur)
        else:
            groups.append(" ".join(cur))
    while len(groups) > max_scenes:  # merge the shortest neighbours
        i = min(range(len(groups) - 1), key=lambda k: len(groups[k]) + len(groups[k + 1]))
        groups[i:i + 2] = [groups[i] + " " + groups[i + 1]]
    return groups


def _first_phrase(text: str, limit: int = 60) -> str:
    first = SENT_SPLIT.split(text.strip(), maxsplit=1)[0].strip()
    if len(first) <= limit:
        return first
    cut = first[:limit].rsplit(" ", 1)[0]
    return (cut or first[:limit]).rstrip(" ,;:-") + "…"


def _query_from(text: str) -> str:
    words = re.findall(r"[A-Za-z0-9']+", text)
    return " ".join(words[:6])


def scenes_from_script(script: str, scene_notes: str = "", topic: str = "") -> dict:
    chunks = split_scenes(script)
    if not chunks:
        raise ValueError("The script is empty.")
    notes = [n.strip() for n in scene_notes.splitlines() if n.strip()]
    scenes = []
    for i, narration in enumerate(chunks):
        hint = notes[i] if i < len(notes) else ""
        scenes.append({
            "id": f"scene-{i + 1:02d}",
            "narration": narration,
            "on_screen_text": _first_phrase(narration),
            "visual_prompt": hint,
            "stock_query": _query_from(hint) or _query_from(topic) or "nature landscape calm",
            "stock_file": None, "stock_credit": None,
        })
    return {"title": (topic or _first_phrase(script, 50)), "hook": scenes[0]["on_screen_text"],
            "script": " ".join(c for c in chunks), "scenes": scenes, "mode": "script"}


def storyboard_from_topic(topic: str, language: str, style: str, duration: int,
                          provider: str, api_key: str, model: str, base_url: str | None = None) -> dict:
    if not topic.strip():
        raise ValueError("Enter a topic.")
    lang = LANGUAGES.get(language, language)
    style_label = STYLES.get(style, {}).get("label", style)
    prompt = (
        f"You write short-video scripts. Topic: {topic}\nLanguage of narration: {lang}\n"
        f"Target length: about {duration} seconds when spoken (about {int(duration * 2.3)} words).\n"
        f"Visual style: {style_label}.\n"
        "Return ONLY JSON: {\"title\":str,\"hook\":str,\"scenes\":[{\"narration\":str,\"on_screen_text\":str,"
        "\"stock_query\":str}]}. Use 4 to 8 scenes. Narration must be natural spoken "
        f"{lang}. stock_query must be 2-4 English words for a stock-footage search. "
        "Do NOT invent Quran verses, Hadith, references or rulings; if no source is given, "
        "write general reflection. Never depict Allah, prophets or angels. No markdown."
    )
    raw = llm.chat(provider, api_key, model, [{"role": "user", "content": prompt}], base_url, temperature=0.6, max_tokens=3500)
    data = llm.parse_json_object(raw)
    rows = data.get("scenes")
    if not isinstance(rows, list) or not rows:
        raise llm.LLMError("The model returned no scenes. Try another model.")
    scenes = []
    for i, r in enumerate(rows[:12]):
        if not isinstance(r, dict) or not str(r.get("narration", "")).strip():
            continue
        nar = str(r["narration"]).strip()
        scenes.append({
            "id": f"scene-{i + 1:02d}", "narration": nar,
            "on_screen_text": str(r.get("on_screen_text") or _first_phrase(nar))[:80],
            "visual_prompt": "", "stock_query": str(r.get("stock_query") or "nature landscape")[:80],
            "stock_file": None, "stock_credit": None,
        })
    if not scenes:
        raise llm.LLMError("The model returned empty scenes.")
    return {"title": str(data.get("title") or topic)[:100], "hook": str(data.get("hook") or scenes[0]["on_screen_text"])[:100],
            "script": " ".join(s["narration"] for s in scenes), "scenes": scenes, "mode": "topic"}
