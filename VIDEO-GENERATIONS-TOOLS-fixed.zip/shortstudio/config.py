"""Static catalogues: visual styles, caption styles, voices, LLM providers."""
from __future__ import annotations

# ---- Visual styles (all drawn procedurally; no model download) -------------
# colors: (bg_top, bg_bottom, accent, text)
STYLES: dict[str, dict] = {
    "cinematic":        {"label": "Cinematic",            "colors": ("#0b1220", "#26364f", "#e8b76a", "#f7f3eb"), "pattern": "glow"},
    "islamic_geometry": {"label": "Islamic geometry",     "colors": ("#0a3a33", "#0f5a4b", "#e0bd75", "#f8f1df"), "pattern": "star"},
    "cyberpunk":        {"label": "Cyberpunk neon",       "colors": ("#07051c", "#2a0f55", "#23e7df", "#f8f3ff"), "pattern": "grid"},
    "hand_drawn":       {"label": "Hand-drawn paper",     "colors": ("#efe3c8", "#d8c29b", "#9d543a", "#2b1d19"), "pattern": "dots"},
    "stickman":         {"label": "Clean explainer",      "colors": ("#fbfaf3", "#e3e5df", "#2678d6", "#15191e"), "pattern": "none"},
    "retro_tv":         {"label": "Retro TV",             "colors": ("#141a21", "#26323c", "#8fb9cd", "#e3e9ef"), "pattern": "scan"},
    "pixel_art":        {"label": "Pixel art",            "colors": ("#101d3a", "#34265f", "#d6a8ff", "#f5edff"), "pattern": "pixels"},
    "clay":             {"label": "Clay / warm",          "colors": ("#8f5340", "#d6a07a", "#fff0d8", "#fff4e5"), "pattern": "blobs"},
    "depth_3d":         {"label": "3D depth",             "colors": ("#0e1730", "#35527f", "#90b7ed", "#f7f7ff"), "pattern": "rings"},
    "kinetic_type":     {"label": "Kinetic typography",   "colors": ("#0e0f12", "#2a2d34", "#f2bd61", "#fbf8f0"), "pattern": "none"},
}

CAPTION_STYLES: dict[str, str] = {
    "box":     "Dark box (most readable)",
    "outline": "Outline, no box",
    "gold":    "Gold text on dark box",
    "off":     "No captions",
}

QUALITY: dict[str, int] = {"720p (fast)": 720, "1080p (slower)": 1080}

# ---- Voices (Microsoft Edge neural voices via edge-tts: free, no key) -------
EDGE_VOICES: dict[str, str] = {
    "bn-BD-NabanitaNeural": "Bengali (Bangladesh) · female",
    "bn-BD-PradeepNeural":  "Bengali (Bangladesh) · male",
    "bn-IN-TanishaaNeural": "Bengali (India) · female",
    "bn-IN-BashkarNeural":  "Bengali (India) · male",
    "hi-IN-SwaraNeural":    "Hindi · female",
    "hi-IN-MadhurNeural":   "Hindi · male",
    "ur-PK-UzmaNeural":     "Urdu · female",
    "ur-PK-AsadNeural":     "Urdu · male",
    "ar-SA-ZariyahNeural":  "Arabic · female",
    "ar-SA-HamedNeural":    "Arabic · male",
    "en-IN-NeerjaNeural":   "English (India) · female",
    "en-IN-PrabhatNeural":  "English (India) · male",
    "en-US-AndrewMultilingualNeural": "English multilingual · male",
}

GTTS_LANGS: dict[str, str] = {"bn": "Bengali", "hi": "Hindi", "ur": "Urdu", "ar": "Arabic", "en": "English"}
MMS_MODELS: dict[str, str] = {"facebook/mms-tts-ben": "Bengali (offline, CC-BY-NC)", "facebook/mms-tts-hin": "Hindi (offline, CC-BY-NC)"}

VOICE_ENGINES: dict[str, str] = {
    "edge": "Edge neural voices (best quality, free, needs internet)",
    "gtts": "Google Translate voice (simple, free)",
    "mms":  "Meta MMS offline model (open weights, non-commercial licence)",
}

# ---- LLM providers (all OpenAI-compatible) ---------------------------------
LLM_PROVIDERS: dict[str, dict] = {
    "openrouter": {"label": "OpenRouter (has free models)", "base_url": "https://openrouter.ai/api/v1",
                   "default_model": "openrouter/free", "key_url": "https://openrouter.ai/keys"},
    "groq":       {"label": "Groq (free tier)", "base_url": "https://api.groq.com/openai/v1",
                   "default_model": "llama-3.3-70b-versatile", "key_url": "https://console.groq.com/keys"},
    "gemini":     {"label": "Google Gemini API (free tier)", "base_url": "https://generativelanguage.googleapis.com/v1beta/openai",
                   "default_model": "", "key_url": "https://aistudio.google.com/apikey"},
    "deepseek":   {"label": "DeepSeek", "base_url": "https://api.deepseek.com/v1",
                   "default_model": "deepseek-chat", "key_url": "https://platform.deepseek.com/api_keys"},
    "openai":     {"label": "OpenAI (paid)", "base_url": "https://api.openai.com/v1",
                   "default_model": "", "key_url": "https://platform.openai.com/api-keys"},
    "custom":     {"label": "Custom OpenAI-compatible URL", "base_url": "", "default_model": "", "key_url": ""},
}

LANGUAGES: dict[str, str] = {"bn": "Bengali", "hi": "Hindi", "ur": "Urdu", "ar": "Arabic", "en": "English"}
