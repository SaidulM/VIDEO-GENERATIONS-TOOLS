"""Fast renderer: Pillow draws backgrounds/text, FFmpeg encodes. No browser, no GPU."""
from __future__ import annotations

import colorsys
import glob
import random
import shutil
import subprocess
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont

from .config import STYLES

FPS = 30


class RenderError(RuntimeError):
    pass


# ---- fonts ------------------------------------------------------------------
FONT_DIRS = ["/usr/share/fonts/truetype/noto", "/usr/share/fonts/opentype/noto", "/usr/share/fonts/truetype/dejavu",
             "/usr/share/fonts", "/content/fonts"]
SCRIPT_FONTS = {
    "bengali": ["NotoSansBengali-Bold.ttf", "NotoSansBengali-Regular.ttf"],
    "devanagari": ["NotoSansDevanagari-Bold.ttf", "NotoSansDevanagari-Regular.ttf"],
    "arabic": ["NotoSansArabic-Bold.ttf", "NotoNaskhArabic-Bold.ttf", "NotoSansArabic-Regular.ttf"],
    "latin": ["NotoSans-Bold.ttf", "DejaVuSans-Bold.ttf", "NotoSans-Regular.ttf"],
}


def detect_script(text: str) -> str:
    for ch in text:
        o = ord(ch)
        if 0x0980 <= o <= 0x09FF:
            return "bengali"
        if 0x0900 <= o <= 0x097F:
            return "devanagari"
        if 0x0600 <= o <= 0x06FF or 0x0750 <= o <= 0x077F:
            return "arabic"
    return "latin"


def find_font(text: str) -> str:
    script = detect_script(text)
    for name in SCRIPT_FONTS[script] + SCRIPT_FONTS["latin"]:
        for d in FONT_DIRS:
            hits = glob.glob(f"{d}/**/{name}", recursive=True)
            if hits:
                return hits[0]
    raise RenderError(f"No font found for {script} text. Run the Setup cell (it installs Noto fonts).")


_FONT_CACHE: dict = {}


def _font(path: str, size: int):
    key = (path, size)
    if key not in _FONT_CACHE:
        _FONT_CACHE[key] = ImageFont.truetype(path, size)
    return _FONT_CACHE[key]


def _word_font(word: str, size: int):
    """Pick the font per word so mixed Bengali/Hindi + English text never shows empty boxes."""
    return _font(find_font(word), size)


def _wrap(draw: ImageDraw.ImageDraw, text: str, size: int, max_w: int) -> list[list[tuple[str, object, float]]]:
    """Return lines of (word, font, width). Words keep their own font."""
    space = draw.textlength(" ", font=_font(find_font("a"), size))
    lines, cur, cur_w = [], [], 0.0
    for word in text.split():
        f = _word_font(word, size)
        ww = draw.textlength(word, font=f)
        add = ww + (space if cur else 0)
        if cur and cur_w + add > max_w:
            lines.append(cur)
            cur, cur_w, add = [], 0.0, ww
        cur.append((word, f, ww))
        cur_w += add
    if cur:
        lines.append(cur)
    return lines or [[("", _font(find_font("a"), size), 0.0)]]


def text_image(text: str, max_w: int, size: int, fill, *, stroke=None, stroke_w=0, box=None,
               border=None, pad=None, align="center") -> Image.Image:
    probe = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    pad = pad if pad is not None else int(size * 0.45)
    space = probe.textlength(" ", font=_font(find_font("a"), size))
    rtl = detect_script(text) == "arabic"
    if rtl:  # Arabic/Urdu: draw whole lines with one font so the shaping engine keeps word order
        f = _font(find_font(text), size)
        raw, cur = [], ""
        for word in text.split():
            trial = (cur + " " + word).strip()
            if cur and probe.textlength(trial, font=f) > max_w - 2 * pad:
                raw.append(cur)
                cur = word
            else:
                cur = trial
        raw.append(cur)
        lines = [[(ln, f, probe.textlength(ln, font=f))] for ln in raw]
        space = 0.0
    else:
        lines = _wrap(probe, text, size, max_w - 2 * pad)
    widths = [sum(w for _, _, w in ln) + space * (len(ln) - 1) for ln in lines]
    lh = int(size * 1.42)
    w, h = int(max(widths)) + 2 * pad + 2 * stroke_w, lh * len(lines) + 2 * pad
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    if box:
        d.rounded_rectangle((0, 0, w - 1, h - 1), radius=int(size * 0.45), fill=box, outline=border, width=3 if border else 0)
    y = pad
    for ln, lw in zip(lines, widths):
        x = (w - lw) / 2 if align == "center" else pad
        for word, f, ww in ln:
            d.text((x, y), word, font=f, fill=fill, stroke_width=stroke_w, stroke_fill=stroke)
            x += ww + space
        y += lh
    return img


# ---- backgrounds ----------------------------------------------------------------
def _hex(c: str):
    c = c.lstrip("#")
    return tuple(int(c[i:i + 2], 16) for i in (0, 2, 4))


def background(style: str, w: int, h: int, seed: int = 0) -> Image.Image:
    st = STYLES.get(style) or STYLES["cinematic"]
    top, bot, accent, _ = (_hex(c) for c in st["colors"])
    rnd = random.Random(seed * 7919 + hash(style) % 1000)
    t = np.linspace(0, 1, h)[:, None, None]
    arr = (np.array(top)[None, None, :] * (1 - t) + np.array(bot)[None, None, :] * t)
    arr = np.repeat(arr, w, axis=1).astype("uint8")
    img = Image.fromarray(arr, "RGB").convert("RGBA")
    ov = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(ov)
    p = st["pattern"]
    ac = lambda a: (*accent, a)
    if p == "glow":
        cx, cy = rnd.randint(int(w * .2), int(w * .8)), rnd.randint(int(h * .15), int(h * .5))
        r = int(min(w, h) * .45)
        d.ellipse((cx - r, cy - r, cx + r, cy + r), fill=ac(70))
        ov = ov.filter(ImageFilter.GaussianBlur(r // 2))
    elif p == "star":
        s = int(w * .26)
        ox, oy = rnd.randint(0, s), rnd.randint(0, s)
        for gx in range(-1, w // s + 2):
            for gy in range(-1, h // s + 2):
                cx, cy, r = gx * s + ox, gy * s + oy, s * .42
                for rot in (0, 45):
                    a = np.radians(rot)
                    pts = [(cx + r * np.cos(a + k * np.pi / 2 + np.pi / 4), cy + r * np.sin(a + k * np.pi / 2 + np.pi / 4)) for k in range(4)]
                    d.polygon(pts, outline=ac(60), width=3)
                d.ellipse((cx - r * .55, cy - r * .55, cx + r * .55, cy + r * .55), outline=ac(35), width=2)
    elif p == "grid":
        step = int(w * .09)
        for x in range(0, w, step):
            d.line((x, 0, x, h), fill=ac(28), width=2)
        for y in range(0, h, step):
            d.line((0, y, w, y), fill=ac(28), width=2)
        for cx, cy, col in ((int(w * .8), int(h * .2), (238, 37, 228)), (int(w * .15), int(h * .82), accent)):
            r = int(w * .3)
            d.ellipse((cx - r, cy - r, cx + r, cy + r), fill=(*col, 60))
        ov = ov.filter(ImageFilter.GaussianBlur(int(w * .06)))
    elif p == "dots":
        step = int(w * .05)
        for x in range(step // 2, w, step):
            for y in range(step // 2, h, step):
                d.ellipse((x - 3, y - 3, x + 3, y + 3), fill=ac(45))
    elif p == "scan":
        for y in range(0, h, 7):
            d.line((0, y, w, y), fill=(0, 0, 0, 70), width=3)
    elif p == "pixels":
        b = int(w * .06)
        for _ in range(int(w * h / (b * b) * .12)):
            x, y = rnd.randrange(0, w, b), rnd.randrange(0, h, b)
            d.rectangle((x, y, x + b, y + b), fill=ac(rnd.randint(20, 70)))
    elif p == "blobs":
        for _ in range(5):
            cx, cy, r = rnd.randint(0, w), rnd.randint(0, h), rnd.randint(int(w * .15), int(w * .4))
            d.ellipse((cx - r, cy - r, cx + r, cy + r), fill=ac(rnd.randint(25, 60)))
        ov = ov.filter(ImageFilter.GaussianBlur(int(w * .05)))
    elif p == "rings":
        cx, cy = int(w * rnd.uniform(.3, .7)), int(h * rnd.uniform(.25, .5))
        for i in range(1, 9):
            r = int(w * .12 * i)
            d.ellipse((cx - r, cy - r, cx + r, cy + r), outline=ac(max(15, 90 - i * 9)), width=4)
    return Image.alpha_composite(img, ov)


def _shade(w: int, h: int, strength: int = 175) -> Image.Image:
    t = np.linspace(0, 1, h)
    alpha = (np.clip(0.18 + 0.82 * t ** 1.6, 0, 1) * strength).astype("uint8")
    arr = np.zeros((h, w, 4), dtype="uint8")
    arr[..., 3] = alpha[:, None]
    return Image.fromarray(arr, "RGBA")


def scene_overlay(style: str, w: int, h: int, title: str, index: int, total: int,
                  hook: str = "", brand: str = "", with_bg: bool = False, seed: int = 0) -> Image.Image:
    """One transparent PNG per scene: shade + hook + title (+brand). With bg for previews."""
    st = STYLES.get(style) or STYLES["cinematic"]
    accent, text_col = _hex(st["colors"][2]), _hex(st["colors"][3])
    base = background(style, w, h, seed) if with_bg else Image.new("RGBA", (w, h), (0, 0, 0, 0))
    base = Image.alpha_composite(base, _shade(w, h, 150 if with_bg else 175))
    if title:
        short = min(w, h)
        timg = text_image(title, int(w * (.86 if h > w else .72)), int(short * .082), (*text_col, 255), stroke=(0, 0, 0, 255), stroke_w=2)
        base.alpha_composite(timg, ((w - timg.width) // 2, int(h * (.30 if h > w else .22))))
    d = ImageDraw.Draw(base)
    if brand:
        f = ImageFont.truetype(find_font(brand), int(min(w, h) * .03))
        d.text((int(w * .07), int(h * .045)), f"{brand}  •  {index + 1:02d}/{total:02d}", font=f, fill=(*accent, 255))
    if hook:
        himg = text_image(hook, int(w * (.86 if h > w else .72)), int(min(w, h) * .04), (*accent, 255), stroke=(0, 0, 0, 255), stroke_w=1, pad=8)
        base.alpha_composite(himg, ((w - himg.width) // 2, int(h * .09)))
    return base


def caption_image(text: str, style: str, caption_style: str, w: int, h: int) -> Image.Image:
    st = STYLES.get(style) or STYLES["cinematic"]
    accent = _hex(st["colors"][2])
    size = int(min(w, h) * .056)
    mw = int(w * (.9 if h > w else .78))
    if caption_style == "outline":
        return text_image(text, mw, size, (255, 255, 255, 255), stroke=(0, 0, 0, 255), stroke_w=max(3, size // 9), pad=6)
    fill = (*accent, 255) if caption_style == "gold" else (255, 255, 255, 255)
    return text_image(text, mw, size, fill, stroke=(0, 0, 0, 255), stroke_w=1, box=(6, 9, 18, 215), border=(*accent, 255))


def preview_frame(style: str, aspect: str, title: str, caption: str, caption_style: str, brand: str = "") -> Image.Image:
    w, h = (360, 640) if aspect == "9:16" else (640, 360)
    sc = 2  # draw at 2x then shrink for crisp text
    img = scene_overlay(style, w * sc, h * sc, title, 0, 1, hook="", brand=brand, with_bg=True)
    if caption and caption_style != "off":
        cimg = caption_image(caption, style, caption_style, w * sc, h * sc)
        bottom = .86 if h > w else .94
        img.alpha_composite(cimg, ((w * sc - cimg.width) // 2, int(h * sc * bottom) - cimg.height))
    return img.convert("RGB").resize((w, h), Image.LANCZOS)


# ---- ffmpeg ---------------------------------------------------------------------
def _ff(args: list[str], what: str):
    r = subprocess.run(["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", *args], capture_output=True, text=True)
    if r.returncode != 0:
        raise RenderError(f"FFmpeg failed while {what}:\n{r.stderr[-1500:]}")


def video_size(aspect: str, quality_height: int) -> tuple[int, int]:
    short = quality_height
    long_ = int(round(short * 16 / 9 / 2)) * 2
    return (short, long_) if aspect == "9:16" else (long_, short)


def render_video(job_dir: Path, scenes: list[dict], spans: list[tuple[float, float]], caps_by_scene: list[list[dict]],
                 narration_wav: str, music: str | None, style: str, aspect: str, quality_height: int,
                 caption_style: str, hook: str, brand: str, total: float, progress=None) -> str:
    if not shutil.which("ffmpeg"):
        raise RenderError("FFmpeg is missing. Run the Setup cell.")
    W, H = video_size(aspect, quality_height)
    tmp = job_dir / "build"
    tmp.mkdir(parents=True, exist_ok=True)
    clips = []
    n = len(scenes)
    for i, scene in enumerate(scenes):
        if progress:
            progress(f"Rendering scene {i + 1}/{n}…")
        start, end = spans[i]
        dur = round(end - start + (0.4 if i == n - 1 else 0), 3)
        frames = max(1, int(round(dur * FPS)))
        ov_path = tmp / f"ov{i}.png"
        scene_overlay(style, W, H, scene.get("on_screen_text", ""), i, n, hook if i == 0 else "", brand, seed=i).save(ov_path)
        stock = scene.get("stock_file")
        inputs: list[str] = []
        if stock and Path(stock).is_file():
            inputs += ["-stream_loop", "-1", "-t", f"{dur}", "-i", stock]
            bg = f"[0:v]scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},fps={FPS},setsar=1[bg];"
        else:
            bgp = tmp / f"bg{i}.png"
            bw, bh = int(W * 1.14) // 2 * 2, int(H * 1.14) // 2 * 2
            background(style, bw, bh, i).convert("RGB").save(bgp)
            inputs += ["-i", str(bgp)]
            # slow pan (cheap Ken-Burns): crop window drifts across a slightly larger picture
            fx = f"(iw-{W})*t/{dur}" if i % 2 == 0 else f"(iw-{W})*(1-t/{dur})"
            bg = (f"[0:v]loop=loop=-1:size=1:start=0,setpts=N/({FPS}*TB),trim=duration={dur},"
                  f"crop={W}:{H}:x='{fx}':y='(ih-{H})/2',setsar=1[bg];")
        inputs += ["-i", str(ov_path)]
        chain = bg + f"[1:v]format=rgba,loop=loop=-1:size=1:start=0,setpts=N/({FPS}*TB),fade=t=in:st=0.1:d=0.5:alpha=1[ov];"
        chain += "[bg][ov]overlay=x=0:y='max(0,40*(1-t/0.5))':format=auto[v0]"
        last, k = "v0", 2
        if caption_style != "off":
            for j, cap in enumerate(caps_by_scene[i]):
                cs = max(0.0, cap["start"] - start)
                ce = min(dur, cap["end"] - start)
                if ce - cs < 0.08:
                    continue
                cp = tmp / f"cap{i}_{j}.png"
                caption_image(cap["text"], style, caption_style, W, H).save(cp)
                inputs += ["-i", str(cp)]
                nxt = f"v{k}"
                chain += (f";[{k}:v]format=rgba,loop=loop=-1:size=1:start=0,"
                          f"setpts=N/({FPS}*TB)+{cs:.3f}/TB,trim=end={ce:.3f}[c{k}]")
                chain += (f";[{last}][c{k}]overlay=x=(main_w-overlay_w)/2:y=main_h*{0.86 if H > W else 0.94}-overlay_h:eof_action=pass:"
                          f"enable='between(t,{cs:.3f},{ce:.3f})'[{nxt}]")
                last, k = nxt, k + 1
        chain += f";[{last}]fade=t=in:st=0:d=0.18,fade=t=out:st={max(0.0, dur - 0.18):.3f}:d=0.18,format=yuv420p[vout]"
        script = tmp / f"f{i}.txt"
        script.write_text(chain, encoding="utf-8")
        out = tmp / f"scene{i:02d}.mp4"
        _ff([*inputs, "-filter_complex_script", str(script), "-map", "[vout]", "-t", f"{dur}", "-r", str(FPS),
             "-c:v", "libx264", "-preset", "ultrafast", "-crf", "24", "-pix_fmt", "yuv420p", "-threads", "0", "-an", str(out)],
            f"rendering scene {i + 1}")
        clips.append(out)
    if progress:
        progress("Joining scenes and mixing audio…")
    lst = tmp / "list.txt"
    lst.write_text("".join(f"file '{c.as_posix()}'\n" for c in clips), encoding="utf-8")
    joined = tmp / "joined.mp4"
    _ff(["-f", "concat", "-safe", "0", "-i", str(lst), "-c", "copy", str(joined)], "joining scenes")
    final = job_dir / "video.mp4"
    args = ["-i", str(joined), "-i", narration_wav]
    if music and Path(music).is_file():
        args += ["-stream_loop", "-1", "-i", music]
        fc = ("[1:a]apad,volume=1.0[n];[2:a]volume=0.10[m];[n][m]amix=inputs=2:duration=first:dropout_transition=0,volume=2[a]")
    else:
        fc = "[1:a]apad[a]"
    _ff([*args, "-filter_complex", fc, "-map", "0:v", "-map", "[a]", "-c:v", "copy", "-c:a", "aac", "-b:a", "160k",
         "-t", f"{total + 0.4:.3f}", "-movflags", "+faststart", str(final)], "mixing audio")
    if not final.exists() or final.stat().st_size < 2048:
        raise RenderError("Render finished but the output file is empty.")
    shutil.rmtree(tmp, ignore_errors=True)
    return str(final)
