"""Voice engines. Every engine returns a 44.1 kHz mono WAV + optional word timings."""
from __future__ import annotations

import asyncio
import concurrent.futures
import re
import subprocess
from pathlib import Path


class TTSError(RuntimeError):
    pass


def _run(coro):
    """Run a coroutine even when Jupyter/Colab already has a running event loop."""
    with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
        return pool.submit(asyncio.run, coro).result()


def probe_duration(path: str | Path) -> float:
    out = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=nw=1:nk=1", str(path)],
                         capture_output=True, text=True)
    try:
        return float(out.stdout.strip())
    except ValueError as exc:
        raise TTSError(f"Cannot read audio duration of {path}: {out.stderr[-200:]}") from exc


def to_wav(src: str | Path, dst: str | Path) -> str:
    r = subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", str(src), "-ac", "1", "-ar", "44100", str(dst)],
                       capture_output=True, text=True)
    if r.returncode != 0:
        raise TTSError("Audio conversion failed: " + r.stderr[-300:])
    return str(dst)


def _clean(text: str) -> str:
    text = re.sub(r"\s+", " ", text).strip()
    if not text:
        raise TTSError("Narration text is empty.")
    return text


# ---- Edge neural voices -----------------------------------------------------
async def _edge_async(text: str, voice: str, rate: int, pitch: int, out_mp3: Path):
    import edge_tts
    comm = edge_tts.Communicate(text, voice, rate=f"{rate:+d}%", pitch=f"{pitch:+d}Hz", boundary="WordBoundary")
    events = []
    with out_mp3.open("wb") as f:
        async for chunk in comm.stream():
            if chunk["type"] == "audio":
                f.write(chunk["data"])
            elif chunk["type"] == "WordBoundary":
                s = chunk["offset"] / 1e7
                events.append({"start": s, "end": s + chunk["duration"] / 1e7, "text": chunk["text"]})
    return events


def edge(text: str, out_wav: str | Path, voice: str, rate: int = 0, pitch: int = 0) -> dict:
    try:
        import edge_tts  # noqa: F401
    except ImportError as exc:
        raise TTSError("edge-tts is not installed. Run the Setup cell.") from exc
    text = _clean(text)
    out_wav = Path(out_wav)
    mp3 = out_wav.with_suffix(".mp3")
    last = None
    for attempt in range(3):
        try:
            events = _run(_edge_async(text, voice, rate, pitch, mp3))
            if mp3.exists() and mp3.stat().st_size > 1000:
                return {"path": to_wav(mp3, out_wav), "events": events}
            last = "no audio received"
        except Exception as exc:  # network / service errors
            last = str(exc)[:200]
    raise TTSError(f"Edge voice failed after 3 tries ({last}). Check the internet connection of the Colab runtime, "
                   "or pick another voice engine.")


# ---- gTTS -------------------------------------------------------------------
def gtts_voice(text: str, out_wav: str | Path, lang: str) -> dict:
    try:
        from gtts import gTTS
    except ImportError as exc:
        raise TTSError("gTTS is not installed. Run the Setup cell.") from exc
    out_wav = Path(out_wav)
    mp3 = out_wav.with_suffix(".mp3")
    try:
        gTTS(_clean(text), lang=lang).save(str(mp3))
    except Exception as exc:
        raise TTSError(f"gTTS failed: {str(exc)[:200]}") from exc
    return {"path": to_wav(mp3, out_wav), "events": []}


# ---- Meta MMS (offline, runs on CPU) ------------------------------------------
_MMS_CACHE: dict = {}


def mms(text: str, out_wav: str | Path, model_id: str) -> dict:
    try:
        import numpy as np
        import soundfile as sf
        import torch
        from transformers import AutoTokenizer, VitsModel
    except ImportError as exc:
        raise TTSError("MMS needs: pip install transformers torch soundfile (see README, optional).") from exc
    if model_id not in _MMS_CACHE:
        _MMS_CACHE[model_id] = (VitsModel.from_pretrained(model_id).eval(), AutoTokenizer.from_pretrained(model_id))
    model, tok = _MMS_CACHE[model_id]
    parts = [p for p in re.split(r"(?<=[.!?।॥])\s+", _clean(text)) if p]
    pieces = []
    for p in parts:
        inputs = tok(p, return_tensors="pt")
        if inputs["input_ids"].shape[1] == 0:
            continue
        with torch.no_grad():
            wave = model(**inputs).waveform[0].cpu().numpy()
        pieces += [wave, np.zeros(int(model.config.sampling_rate * 0.18), dtype="float32")]
    if not pieces:
        raise TTSError("MMS produced no audio for this text.")
    raw = Path(out_wav).with_suffix(".raw.wav")
    sf.write(str(raw), np.concatenate(pieces), model.config.sampling_rate)
    return {"path": to_wav(raw, out_wav), "events": []}


def synthesize(text: str, engine: str, out_wav: str | Path, *, voice: str = "", rate: int = 0, pitch: int = 0,
               lang: str = "bn", mms_model: str = "facebook/mms-tts-ben") -> dict:
    Path(out_wav).parent.mkdir(parents=True, exist_ok=True)
    if engine == "edge":
        res = edge(text, out_wav, voice, rate, pitch)
    elif engine == "gtts":
        res = gtts_voice(text, out_wav, lang)
    elif engine == "mms":
        res = mms(text, out_wav, mms_model)
    else:
        raise TTSError(f"Unknown voice engine: {engine}")
    res["duration"] = probe_duration(res["path"])
    return res
