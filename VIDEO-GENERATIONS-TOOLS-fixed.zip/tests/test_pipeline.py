"""Offline tests: no network, no API keys. Voice is faked with a generated tone."""
import json
import shutil
import subprocess
from pathlib import Path

import pytest

from shortstudio import captions, planner, render
from shortstudio.pipeline import Settings, generate

BN = "আমরা প্রতিদিন নতুন কিছু শিখতে পারি। ধৈর্য ধরলে সব কাজ সহজ হয়ে যায়। আজকের গল্পটি শুনুন এবং নিজের জীবনে কাজে লাগান। আল্লাহর উপর ভরসা রাখুন।"
needs_ffmpeg = pytest.mark.skipif(not shutil.which("ffmpeg"), reason="ffmpeg missing")


def test_split_scenes_keeps_all_text():
    chunks = planner.split_scenes(BN, target_words=8)
    assert len(chunks) >= 2
    assert " ".join(chunks).split() == BN.split()


def test_scenes_from_script_has_queries():
    board = planner.scenes_from_script(BN, "mosque at dawn\nrain on window")
    assert board["scenes"][0]["stock_query"] == "mosque at dawn"
    assert all(s["narration"] for s in board["scenes"])


def test_word_times_exact_and_estimated():
    board = {"scenes": [{"narration": "one two three four."}, {"narration": "five six seven eight."}]}
    words = " ".join(s["narration"] for s in board["scenes"]).split()
    ev = [{"start": i * 0.5, "end": i * 0.5 + 0.4, "text": w} for i, w in enumerate(words)]
    t, note = captions.word_times(board["scenes"], ev, 4.0)
    assert "exact" in note and len(t) == 8
    t2, note2 = captions.word_times(board["scenes"], [], 4.0)
    assert "estimated" in note2 and abs(t2[-1][1] - 4.0) < 1e-6
    spans = captions.scene_spans(board["scenes"], t, 4.0)
    assert spans[0][0] == 0 and spans[-1][1] >= 4.0


def test_srt_format(tmp_path):
    p = captions.write_srt([{"start": 0, "end": 1.5, "text": "hi"}], tmp_path / "a.srt")
    assert "00:00:01,500" in Path(p).read_text()


def test_bengali_text_renders():
    img = render.text_image("আল্লাহর উপর ভরসা", 600, 60, (255, 255, 255, 255))
    assert img.width > 100 and img.getbbox() is not None


@needs_ffmpeg
@pytest.mark.parametrize("style", ["cinematic", "islamic_geometry", "cyberpunk"])
def test_full_render_with_fake_voice(tmp_path, monkeypatch, style):
    from shortstudio import tts

    def fake(text, engine, out, **kw):
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", "sine=frequency=220:duration=9",
                        "-ac", "1", "-ar", "44100", str(out)], check=True)
        n = len(text.split())
        ev = [{"start": i * 9 / n, "end": (i + 0.8) * 9 / n, "text": w} for i, w in enumerate(text.split())]
        return {"path": str(out), "events": ev, "duration": 9.0}

    monkeypatch.setattr(tts, "synthesize", fake)
    res = generate(Settings(script=BN, style=style, quality_height=360, brand="Short Story"),
                   tmp_path / "w", tmp_path / "e")
    v = Path(res["video"])
    assert v.exists() and v.stat().st_size > 5000
    info = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "stream=codec_type,width,height:format=duration",
                           "-of", "json", str(v)], capture_output=True, text=True).stdout
    data = json.loads(info)
    kinds = {s["codec_type"] for s in data["streams"]}
    assert kinds == {"video", "audio"}
    assert abs(float(data["format"]["duration"]) - 9.4) < 0.6
    assert Path(res["srt"]).exists() and Path(res["timestamps"]).exists()
